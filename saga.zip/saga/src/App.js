import "./App.css"
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';


function App() {
  return (
   
    <div className="App">
     <h1>Recipe App</h1>
     <div style={{display:"flex",justifyContent:"center",textAlign:"center"}}>
     <Box
    component="form"
    sx={{
      '& .MuiTextField-root': { m: 1, width: '35ch' },
    }}
    noValidate
    autoComplete="off"
  >
    <div>
    <TextField
          label="search"
          id="outlined-size-small"
          size="small"
        />
     </div>
     </Box> 
     <div style={{marginTop:"9px"}}> 
     <Button variant="contained" size="medium">
          search
        </Button>
        </div>
     </div>
    </div>
  );
}

export default App;
